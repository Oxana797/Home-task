package com.example.demo;


public enum Message {
    RECORD,
    REPOST,
    COMMENT;
}
