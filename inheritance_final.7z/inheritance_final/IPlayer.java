package com.example.demo;


import java.io.File;

public interface IPlayer {

    void play(File file);
}
