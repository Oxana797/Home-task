package com.example.demo;


public interface IPrinter {

    void print(String message);
}
