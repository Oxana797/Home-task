package com.example.myDemo;

public class DishwasherIsBusyException extends Exception {
 
    public DishwasherIsBusyException(String message) {
        super(message);
    }
}