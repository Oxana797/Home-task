package com.example.myDemo;

public class User{

	String name;
	int age;
	
	public User(String s, int i){
		name = s;
		age = i;
	}

}